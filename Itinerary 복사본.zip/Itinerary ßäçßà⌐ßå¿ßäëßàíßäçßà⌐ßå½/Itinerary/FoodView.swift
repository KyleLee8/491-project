//
//  SchedulerView.swift
//  Itinerary
//
//  Created by Kyle Lee on 10/10/24.
//

import SwiftUI

// placeholder

struct FoodView: View {
    var body: some View{
        Text("This is the Food app screen")
            .font(.largeTitle)
            .padding()
    }
}

struct FoodView_Previews: PreviewProvider{
    static var previews: some View{
        FoodView()
    }
}



