//
//  SchedulerView.swift
//  Itinerary
//
//  Created by Kyle Lee on 10/10/24.
//

import SwiftUI

// placeholder

struct HotelView: View {
    var body: some View{
        Text("This is the Hotel app screen")
            .font(.largeTitle)
            .padding()
    }
}

struct HotelView_Previews: PreviewProvider{
    static var previews: some View{
        HotelView()
    }
}

