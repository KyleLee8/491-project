//
//  SchedulerView.swift
//  Itinerary
//
//  Created by Kyle Lee on 10/10/24.
//

import SwiftUI

// placeholder

struct FlightView: View {
    var body: some View{
        Text("This is the Flight app screen")
            .font(.largeTitle)
            .padding()
    }
}

struct FlightView_Previews: PreviewProvider{
    static var previews: some View{
        FlightView()
    }
}


