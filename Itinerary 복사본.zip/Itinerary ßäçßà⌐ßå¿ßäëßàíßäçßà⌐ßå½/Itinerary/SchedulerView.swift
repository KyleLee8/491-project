//
//  SchedulerView.swift
//  Itinerary
//
//  Created by Kyle Lee on 10/10/24.
//

import SwiftUI

// placeholder

struct SchedulerView: View {
    var body: some View{
        Text("This is the scheudling app screen")
            .font(.largeTitle)
            .padding()
    }
}

struct SchedulerView_Previews: PreviewProvider{
    static var previews: some View{
        SchedulerView()
    }
}
